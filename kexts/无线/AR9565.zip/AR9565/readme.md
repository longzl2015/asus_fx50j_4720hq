An open source kernel extension providing patches for unsupported Atheros cards.

AR946X (AR9462 & AR9463)
AR9485
AR9565
Features
Boot args:

AR946X: (Default)
AR9485: -ath9485
AR9565: -ath9565

Installation

- This kext version requires LILU plugin version 1.2.0+
- Download Lilu.kext, ATH9KInjector.kext and ATH9KFixup.kext
- Install them to /S/L/E (Clover injection won't work)
- User -ath9485 boot arg for AR9485 and -ath9565 for AR9565 (If you don't use any boot args it will do the patching for AR946X by default)
- Optional (Rebuild Caches)
